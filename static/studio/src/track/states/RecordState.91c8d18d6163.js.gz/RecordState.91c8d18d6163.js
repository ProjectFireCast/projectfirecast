export default class {
  constructor(track) {
    this.track = track;
  }

  static getClass() {
    return '.state-record';
  }
}
